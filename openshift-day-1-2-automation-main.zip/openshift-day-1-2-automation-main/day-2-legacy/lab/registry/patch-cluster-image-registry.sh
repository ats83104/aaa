# create pvc before patch
oc patch configs.imageregistry.operator.openshift.io/cluster --type merge -p '{"spec": {"managementState": "Managed","replicas": 1,"rolloutStrategy": "Recreate","storage": {"managementState": "Managed","pvc": {"claim": "image-registry-storage"}}}}'
