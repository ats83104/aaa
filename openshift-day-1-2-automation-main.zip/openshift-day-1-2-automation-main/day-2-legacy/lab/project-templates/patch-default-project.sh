# create default-template before patching
oc patch  project.config.openshift.io/cluster --type merge -p '{"spec":{"projectRequestTemplate":{"name":"project-request"}}}'


