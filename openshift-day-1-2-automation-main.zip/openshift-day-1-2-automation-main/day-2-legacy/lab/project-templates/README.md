 Templates anlegen

 oc create -f project-template-bvaeb.yaml -n openshift-config
 oc create -f project-template-svs.yaml -n openshift-config
 oc create -f project-template-bvaeb.yaml -n openshift-config

 Default Template konfigurieren

  oc edit project.config.openshift.io/cluster

  spec:
  projectRequestTemplate:
    name: project-request

Mandanten Project anlegen

 oc process project-request-svs -n openshift-config -p=PROJECT_NAME=tw-svs-test | oc create -f -