Network policies are part of the project templates.

No need to apply when the templates is used for creating the project.