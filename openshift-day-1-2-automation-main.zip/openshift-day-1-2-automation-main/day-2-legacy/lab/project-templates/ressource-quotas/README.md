default resource quotas and limit ranges are part of the project templates.

No need to apply it in project created with template.