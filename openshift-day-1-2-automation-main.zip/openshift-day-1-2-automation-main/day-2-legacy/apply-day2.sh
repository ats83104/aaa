#!/bin/bash


# Load environment variables from cluster.env file
if [[ -f "cluster.env" ]]; then
  echo "Loading cluster environment variables from cluster.env file."
  source "cluster.env"
fi

# Prompt user for OpenShift cluster login information if not set in environment variables
if [[ -z "$SERVER_URL" ]]; then
  read -p "Server URL [https://<hostname>:<port>]: " server_url
else
  echo "SERVER_URL: $SERVER_URL"
  server_url=$SERVER_URL
fi

if [[ -z "$USERNAME" ]]; then
  read -p "Username: " username
else
  echo "Username: $USERNAME"
  username=$USERNAME
fi

read -s -p "Password: " password
echo ""

# Log in to the OpenShift cluster
oc login --insecure-skip-tls-verify=true "$server_url" -u "$username" -p "$password"
if [[ $? -ne 0 ]]; then
  echo "Failed to log in to OpenShift cluster. Exiting."
  exit 1
fi

# Get the name of the logged-in cluster
cluster_name=$(oc config get-contexts | awk '/^\*/ {print $3}')

# Check if the script should run in dry-run mode
dryrun=false
if [[ "$1" == "--dry-run" ]]; then
  echo "Running in dry-run mode."
  dryrun=true
fi

# Ask user if they want to proceed
read -p "Logged in to OpenShift cluster \"$cluster_name\". Do you want to proceed? [y/n] " proceed
if [[ "$proceed" != "y" && "$proceed" != "Y" ]]; then
  echo "Exiting."
  exit 0
fi

# Set the base directory to the directory where this script is stored
base_dir="$(dirname "$(realpath "$0")")"


# Loop through all subdirectories and apply OpenShift resources
for dir in $(find "$base_dir" -type d); do
  echo ""
  if [[ -d "$dir" && "$dir" == "$base_dir" ]]; then
    echo "skip base dir $base_dir"
    continue
  fi

  if [[ -d "$dir" ]]; then
    # Check if the directory should be ignored
    if [[ -f "$dir"/ignore.txt ]]; then
      echo "Ignoring directory: $dir"
      continue
    fi
    echo ""
    echo "=============================="
    echo "Processing directory: $dir"
    echo ""
    # Apply all yaml files in the current directory
    for file in "$dir"/*.yaml; do
      if [[ -f "$file" ]]; then
        echo "Applying $file..."
        if [[ "$dryrun" == true ]]; then
          echo "oc apply -f $file"
        else
          oc apply -f "$file"
          rc=$?
          if [[ $rc -ne 0 ]]; then
            echo "$(date) - Error applying $file (return code: $rc)" >> error.log
            echo "$(date) - Error applying $file (return code: $rc)"
          fi
        fi
      fi
    done
    echo ""
    echo "------------------"
    echo ""
    # Call all sh scripts in the current directory
    for file in "$dir"/*.sh; do
      if [[ -f "$file" ]]; then
        echo "Executing $file..."
        if [[ "$dryrun" == true ]]; then
          echo "$file"
        else
          "$file"
          rc=$?
          if [[ $rc -ne 0 ]]; then
            echo "$(date) - Error executing $file (return code: $rc)" >> error.log
            echo "$(date) - Error executing $file (return code: $rc)"
          fi
        fi
      fi
    done
  fi
done
