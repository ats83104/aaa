# apply day 2 openshift operations

## usage of apply.sh

The script parses all subdirs of the scripts base dir and executes aaply -f with all yaml files and executes all sh scripts in directory.

When the file ignore.txt is in directory all files are ignored.

Script imports cluster.env with username and api address.

If not set scripts prompts for user, password and api address of openshift cluster.


## Test with dry-run
The script can be called with option dry-run to just log the steps and commands without applying it.
apply.sh --dry-run

## Error
In case of errors the step with error is logged to error.log file
The script does not stop when an error occurs.