# CSV file name
csv_file="pod_info.csv"

echo "Creating cvs file $csv_file"

# Add headers to the CSV file
echo "Pod Name, Namespace, Node Name, CPU Limits, CPU Requests, Memory Limits, Memory Requests" > "$csv_file"


# Get a list of all pods in the cluster with -o custom-columns
oc get pods --all-namespaces -o custom-columns=POD:.metadata.name,NAMESPACE:.metadata.namespace,NODE:.spec.nodeName,LIMITS_CPU:.spec.containers[*].resources.limits.cpu,REQUESTS_CPU:.spec.containers[*].resources.requests.cpu,LIMITS_MEMORY:.spec.containers[*].resources.limits.memory,REQUESTS_MEMORY:.spec.containers[*].resources.requests.memory --no-headers | \
while IFS= read -r line; do
    pod_name=$(echo "$line" | awk '{print $1}')
    namespace=$(echo "$line" | awk '{print $2}')
    node_name=$(echo "$line" | awk '{print $3}')
    cpu_limits=$(echo "$line" | awk '{print $4}')
    cpu_requests=$(echo "$line" | awk '{print $5}')
    memory_limits=$(echo "$line" | awk '{print $6}')
    memory_requests=$(echo "$line" | awk '{print $7}')

    # Append data to the CSV file
    echo "$pod_name, $namespace, $node_name, $cpu_limits, $cpu_requests, $memory_limits, $memory_requests" >> "$csv_file"
done

echo "CSV file '$csv_file' generated with pod information including CPU and memory limits and requests."
