##########################################################################################
##################################### UTILS START ########################################
##########################################################################################
function init() {
  red=$(tput setaf 1)
  green=$(tput setaf 2)
  yellow=$(tput setaf 3)
  turq=$(tput setaf 6)
  reset=$(tput sgr0)
  debug=false
  show_help=false
  config_path=""
  clients_download_url="https://mirror.openshift.com/pub/openshift-v4/x86_64/clients/ocp"
  install_artifacts_dir=""
  openshift_install_cli_path=""
  client_dir=""
  oc_cli_path=""
  secrets_dir_path=""
  pull_secret_path=""
}

function help() {
  COMMAND=$1
  echo
  case $COMMAND in
  "install")
    echo "Performs pre-requesites tasks and starts an Openshift on-prem vSphere installation. It is ${green}mandatory${reset} to provide the vSphere password as an environment variable beforehand. See examples below."
    echo
    echo "Flags:"
    echo " -c, --config:   [${green}mandatory${reset}] Path to configuration file."
    echo " -d, --debug:    Interactive debug mode. Stops at each step, hit 'enter' to continue."
    echo
    echo "Examples:"
    echo "  # Start installation procedure"
    echo "  VSPHERE_OPENSHIFT_PASSWORD='<vsphere-password>' ./installer.sh install -c env/lab.env.sh"
    echo
    echo "  # Start installation procedure in interactive debug mode"
    echo "  VSPHERE_OPENSHIFT_PASSWORD='<vsphere-password>' ./installer.sh install -d -c env/lab.env.sh"
    ;;
  "destroy")
    echo "Destroys a running cluster given it was previosly installed with this script. The cluster installation data is archived into ${yellow}'<work-path>/archive/<cluster-name>_<date>'${reset}."
    echo
    echo "Flags:"
    echo " -c, --config:   [${green}mandatory${reset}] Path to configuration file."
    echo " -d, --debug:    Interactive debug mode. Stops at each step, hit 'enter' to continue."
    echo
    echo "Examples:"
    echo "  # Start destruction procedure"
    echo "  ./installer.sh destroy -c env/lab.env.sh"
    echo
    echo "  # Start destruction procedure in interactive debug mode"
    echo "  ./installer.sh destroy -d -c env/lab.env.sh"
    ;;
  *)
    echo "The install script automates on-prem Openshift installation on vSphere. It requires the ${yellow}env/*.env.sh${reset} to be filled entirely and ${yellow}VSPHERE_OPENSHIFT_PASSWORD${reset} envronment variable to be set."
    echo
    echo "Commands:"
    echo " install   Performs all required installation pre-requesites tasks and starts installation."
    echo " destroy   Destroys running cluster given it was installed with this script."
    echo
    echo "Global flags:"
    echo " -c, --config:   [${green}mandatory${reset}] Path to configuration file."
    echo " -d, --debug:    Interactive debug mode. Stops at each step, hit 'enter' to continue."
    ;;
  esac

  echo
  echo "Usage: "
  echo "VSPHERE_OPENSHIFT_PASSWORD='<vsphere-password>' ./installer.sh <command> [flags]"
  echo
  echo "Use \"./installer.sh <command> --help\" for more information about a given command."
}

function step() {
  echo
  if [[ $1 -lt 10 ]]; then
    echo "${green}---------------${reset}"
    echo "${green}>>>${reset} STEP 0$1 ${green}>>>${reset}"
  else
    echo "${green}---------------${reset}"
    echo "${green}>>>${reset} STEP $1 ${green}>>>${reset}"
  fi

  if [[ $debug = "true" ]]; then
    read -p "${yellow}>>>  DEBUG  >>>${reset}"
  fi
}

function step_done() {
  if [[ $debug = "true" ]]; then
    echo "${green}>>>${reset}  Done.  ${green}>>>${reset}"
    echo "${yellow}>>>  DEBUG  >>>${reset}"
    read -p "${green}---------------${reset}"

  else
    echo "${green}>>>${reset}  Done.  ${green}>>>${reset}"
    echo "${green}---------------${reset}"
  fi
}

function err() {
  echo "${red}ERROR${reset} $1"
}

function download_and_decompress_archive() {
  local url="$1"
  local topath="$2"
  local archiveName=$(basename $url)
  local archiveFilepath="$topath/$archiveName"

  echo "Downloading $archiveName..."
  curl \
    --output $archiveFilepath \
    --proxy $HTTP_PROXY \
    -O -J -L $url

  echo "Unpacking $archiveName..."
  tar -xvf $archiveFilepath -C $topath
}
##########################################################################################
###################################### UTILS END #########################################
##########################################################################################

function load_config() {
  step 1

  echo "Loading configuration..."

  if [[ -z $1 ]]; then
    err "no configuration file provided"
    exit 1
  fi

  if [[ ! -f $1 ]]; then
    err "configuration file $1 not found"
    exit 1
  fi

  source $1

  validate

  export $VSPHERE_OPENSHIFT_PASSWORD
  WORK_PATH=$HOME/$WORK_DIR_NAME
  http_proxy=$HTTP_PROXY
  https_proxy=$HTTPS_PROXY
  no_proxy=$NO_PROXY
  install_artifacts_dir=$WORK_PATH/install-artifacts
  openshift_install_cli_path=$install_artifacts_dir/openshift-install
  client_dir=$WORK_PATH/client
  oc_cli_path=$client_dir/oc
  secrets_dir_path=$WORK_PATH/secrets
  pull_secret_path=$secrets_dir_path/pull_secret

  print_loaded_config

  step_done
}

function validate() {
  local valid="true"

  if [[ -z "$VSPHERE_OPENSHIFT_PASSWORD" ]]; then
    valid="false"
    err "${yellow}VSPHERE_OPENSHIFT_PASSWORD${reset} must be set; see --help for more info"
  fi

  if [[ -z "$OS_VERSION" ]]; then
    valid="false"
    err "${yellow}OS_VERSION${reset} must be set"
  fi

  if [[ -z "$LOCAL_REPO_PATH" ]]; then
    valid="false"
    err "${yellow}LOCAL_REPO_PATH${reset} must be set"
  fi

  if [[ ! -d $LOCAL_REPO_PATH ]]; then
    echo $LOCAL_REPO_PATH

    valid="false"
    err "${yellow}LOCAL_REPO_PATH${reset} must be the directory of the code"
  fi

  if [[ -z "$WORK_DIR_NAME" ]]; then
    valid="false"
    err "${yellow}WORK_DIR_NAME${reset} must be set"
  fi

  if [[ -z "$BASE_DOMAIN" ]]; then
    valid="false"
    err "${yellow}BASE_DOMAIN${reset} must be set"
  fi

  if [[ -z "$CLUSTER_NAME" ]]; then
    valid="false"
    err "${yellow}CLUSTER_NAME${reset} must be set"
  fi

  if [[ -z "$PHYSICAL_NETWORK_RANGE" ]]; then
    valid="false"
    err "${yellow}PHYSICAL_NETWORK_RANGE${reset} must be set"
  fi

  if [[ -z "$VSPHERE_CLUSTER_NAME" ]]; then
    valid="false"
    err "${yellow}VSPHERE_CLUSTER_NAME${reset} must be set"
  fi

  if [[ -z "$VSPHERE_DATACENTER_NAME" ]]; then
    valid="false"
    err "${yellow}VSPHERE_DATACENTER_NAME${reset} must be set"
  fi

  if [[ -z "$VSPHERE_VCENTER_DOMAIN" ]]; then
    valid="false"
    err "${yellow}VSPHERE_VCENTER_DOMAIN${reset} must be set"
  fi

  if [[ -z "$VSPHERE_DATASTORE_NAME" ]]; then
    valid="false"
    err "${yellow}VSPHERE_DATASTORE_NAME${reset} must be set"
  fi

  if [[ -z "$VSPHERE_NETWORK_NAME" ]]; then
    valid="false"
    err "${yellow}VSPHERE_NETWORK_NAME${reset} must be set"
  fi

  if [[ -z "$VSPHERE_OPENSHIFT_USERNAME" ]]; then
    valid="false"
    err "${yellow}VSPHERE_OPENSHIFT_USERNAME${reset} must be set"
  fi

  if [[ -z "$VSPHERE_DATACENTER_FOLDER_PATH" ]]; then
    valid="false"
    err "${yellow}VSPHERE_DATACENTER_FOLDER_PATH${reset} must be set"
  fi

  if [[ -z "$VSPHERE_DATACENTER_RESOURCE_POOL_PATH" ]]; then
    valid="false"
    err "${yellow}VSPHERE_DATACENTER_RESOURCE_POOL_PATH${reset} must be set"
  fi

  if [[ -z "$VSPHERE_API_VIP" ]]; then
    valid="false"
    err "${yellow}VSPHERE_API_VIP${reset} must be set"
  fi

  if [[ -z "$VSPHERE_INGRESS_VIP" ]]; then
    valid="false"
    err "${yellow}VSPHERE_INGRESS_VIP${reset} must be set"
  fi

  if [[ -z "$HTTP_PROXY" ]]; then
    valid="false"
    err "${yellow}HTTP_PROXY${reset} must be set"
  fi

  if [[ -z "$HTTPS_PROXY" ]]; then
    valid="false"
    err "${yellow}HTTPS_PROXY${reset} must be set"
  fi

  if [[ -z "$NO_PROXY" ]]; then
    valid="false"
    err "${yellow}NO_PROXY${reset} must be set"
  fi

  if [[ -z "$TRUST_BUNDLE_FILEPATH" ]]; then
    valid="false"
    err "${yellow}TRUST_BUNDLE_FILEPATH${reset} must be set"
  fi

  if [[ ! -f $TRUST_BUNDLE_FILEPATH ]]; then
    valid="false"
    err "${yellow}TRUST_BUNDLE_FILEPATH${reset} must point to an existing root certificate file"
  fi

  if [[ -z "$OFFLINE_ACCESS_TOKEN" ]]; then
    valid="false"
    err "${yellow}OFFLINE_ACCESS_TOKEN${reset} must be set"
  fi

  if [[ "$valid" != "true" ]]; then
    err "validation failed"
    err "set configuration variables and restart the installation"
    exit 1
  fi
}

function print_loaded_config() {
  echo "Configuration parameters: "
  echo "  - ${yellow}OS_VERSION${reset}: $OS_VERSION"
  echo "  - ${yellow}LOCAL_REPO_PATH${reset}: $LOCAL_REPO_PATH"
  echo "  - ${yellow}WORK_PATH${reset}: $WORK_PATH"
  echo "  - ${yellow}BASE_DOMAIN${reset}: $BASE_DOMAIN"
  echo "  - ${yellow}CLUSTER_NAME${reset}: $CLUSTER_NAME"
  echo "  - ${yellow}PHYSICAL_NETWORK_RANGE${reset}: $PHYSICAL_NETWORK_RANGE"
  echo "  - ${yellow}VSPHERE_CLUSTER_NAME${reset}: $VSPHERE_CLUSTER_NAME"
  echo "  - ${yellow}VSPHERE_DATACENTER_NAME${reset}: $VSPHERE_DATACENTER_NAME"
  echo "  - ${yellow}VSPHERE_VCENTER_DOMAIN${reset}: $VSPHERE_VCENTER_DOMAIN"
  echo "  - ${yellow}VSPHERE_DATASTORE_NAME${reset}: $VSPHERE_DATASTORE_NAME"
  echo "  - ${yellow}VSPHERE_NETWORK_NAME${reset}: $VSPHERE_NETWORK_NAME"
  echo "  - ${yellow}VSPHERE_OPENSHIFT_USERNAME${reset}: $VSPHERE_OPENSHIFT_USERNAME"
  echo "  - ${yellow}VSPHERE_OPENSHIFT_PASSWORD${reset}: $VSPHERE_OPENSHIFT_PASSWORD"
  echo "  - ${yellow}VSPHERE_DATACENTER_FOLDER_PATH${reset}: $VSPHERE_DATACENTER_FOLDER_PATH"
  echo "  - ${yellow}VSPHERE_DATACENTER_RESOURCE_POOL_PATH${reset}: $VSPHERE_DATACENTER_RESOURCE_POOL_PATH"
  echo "  - ${yellow}VSPHERE_API_VIP${reset}: $VSPHERE_API_VIP"
  echo "  - ${yellow}VSPHERE_INGRESS_VIP${reset}: $VSPHERE_INGRESS_VIP"
  echo "  - ${yellow}HTTP_PROXY${reset}: $HTTP_PROXY"
  echo "  - ${yellow}HTTPS_PROXY${reset}: $HTTPS_PROXY"
  echo "  - ${yellow}NO_PROXY${reset}: $NO_PROXY"
  echo "  - ${yellow}TRUST_BUNDLE_FILEPATH${reset}: $TRUST_BUNDLE_FILEPATH"
}

function create_installation_directory_structure() {
  step 2

  echo "Checking installation directory structure..."
  if [[ -d $WORK_PATH ]] &&
    [[ -d $WORK_PATH/client ]] &&
    [[ -d $WORK_PATH/cluster ]] &&
    [[ -d $install_artifacts_dir ]] &&
    [[ -d $WORK_PATH/secrets ]]; then
    echo "Installation directory structure exists."
  else
    echo "Installation directory structure does not exist. Creating now."
    mkdir -p $WORK_PATH/client
    mkdir $WORK_PATH/cluster
    mkdir $install_artifacts_dir
    mkdir $WORK_PATH/secrets
  fi

  step_done
}

function download_and_decompress_installer() {
  step 3

  echo "Checking openshift installer existence..."

  if [[ -f $openshift_install_cli_path ]]; then
    echo "${yellow}openshift-installer${reset} binary is present in $install_artifacts_dir."
    return
  fi

  local installer_archive_download_url="$clients_download_url/$OS_VERSION/openshift-install-linux.tar.gz"

  download_and_decompress_archive $installer_archive_download_url $install_artifacts_dir

  step_done
}

function download_and_decompress_cli() {
  step 4

  echo "Checking openshift client existence..."

  if [[ -f $oc_cli_path ]]; then
    echo "${yellow}oc${reset} binary is present in $client_dir."
    return
  fi

  local oc_archive_download_url="$clients_download_url/$OS_VERSION/openshift-client-linux.tar.gz"

  download_and_decompress_archive $oc_archive_download_url $client_dir

  step_done
}

function download_pull_secret() {
  step 5

  echo "Checking pull secret existence..."

  if [[ -f $pull_secret_path ]]; then
    echo "${yellow}pull secret${reset} is present in $secrets_dir_path."
    load_pull_secret
    return
  fi

  echo "Downloading pull secret..."

  local bearer_url=https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token
  local bearer=$(curl \
    --silent \
    --proxy $HTTP_PROXY \
    --data-urlencode "grant_type=refresh_token" \
    --data-urlencode "client_id=cloud-services" \
    --data-urlencode "refresh_token=${OFFLINE_ACCESS_TOKEN}" \
    $bearer_url | jq -r .access_token)
  local pull_secret_download_url=https://api.openshift.com/api/accounts_mgmt/v1/access_token
  curl \
    --proxy $HTTP_PROXY \
    -X POST $pull_secret_download_url \
    --header "Content-Type:application/json" \
    --header "Authorization: Bearer $bearer" >$pull_secret_path

  load_pull_secret

  step_done
}

function load_pull_secret() {
  echo "Loading pull secret..."
  export PULL_SECRET=$(cat $pull_secret_path)
}

function loading_trust_bundle() {
  step 6

  echo "Loading trust bundle..."

  if [[ -f /etc/pki/ca-trust/source/anchors/3bc63c8b.0 ]] &&
    [[ -f /etc/pki/ca-trust/source/anchors/b7f6f08c.0 ]]; then
    export TRUST_BUNDLE=$(cat /etc/pki/ca-trust/source/anchors/3bc63c8b.0 /etc/pki/ca-trust/source/anchors/b7f6f08c.0 | awk '{print "  " $0}')
  else
    export TRUST_BUNDLE=$(cat $TRUST_BUNDLE_FILEPATH | awk '{print "  " $0}')
  fi

  echo "Trust bundle loaded."

  step_done
}

function generate_ssh() {
  step 7

  echo "Generatinge SSH key pair..."
  if [[ -f $WORK_PATH/install-artifacts/ssh/osnode ]] ||
    [[ -f $WORK_PATH/install-artifacts/ssh/osnode.pub ]]; then
    echo "SSH key pair exist."

    export SSH_PUBLIC_KEY=$(cat $WORK_PATH/install-artifacts/ssh/osnode.pub)
    echo "SSH public key: $SSH_PUBLIC_KEY"

    step_done

    return
  fi

  if [[ ! -d $WORK_PATH/install-artifacts/ssh/ ]]; then
    echo "Creating ssh directory: ~/$WORK_DIR_NAME/install-artifacts/ssh"
    mkdir $WORK_PATH/install-artifacts/ssh
  else
    echo "SSH directory exit."
  fi

  if [[ ! -f $WORK_PATH/install-artifacts/ssh/osnode ]] ||
    [[ ! -f $WORK_PATH/install-artifacts/ssh/osnode.pub ]]; then
    echo "Generating SSH key pair..."
    ssh-keygen -t ed25519 -N '' -f $WORK_PATH/install-artifacts/ssh/osnode -q
  else
    echo "SSH key pair exist."
  fi

  export SSH_PUBLIC_KEY=$(cat $WORK_PATH/install-artifacts/ssh/osnode.pub)
  echo "SSH public key: $SSH_PUBLIC_KEY"

  step_done
}

function generate_install_config() {
  step 8

  echo "Generating install-config.yaml..."

  envsubst <$LOCAL_REPO_PATH/day-1/base/install-artifacts/install-config-template.yaml >$WORK_PATH/install-artifacts/install-config.yaml

  step_done
}

function start_install() {
  step 9

  echo "Running last checks before starting cluster installation..."
  if [[ ! -d $WORK_PATH/cluster/$CLUSTER_NAME ]]; then
    echo "Creating cluster directory: ~/$WORK_DIR_NAME/cluster/$CLUSTER_NAME"
    mkdir $WORK_PATH/cluster/$CLUSTER_NAME
  else
    echo "Cluster directory exist."
  fi

  if [[ ! -f $WORK_PATH/cluster/$CLUSTER_NAME/install-config.yaml ]]; then
    echo "Moving install-config.yaml to cluster directory..."
    mv $WORK_PATH/install-artifacts/install-config.yaml $WORK_PATH/cluster/$CLUSTER_NAME
  else
    echo "install-config.yaml in cluster directory."
  fi

  if [[ $(ls -A -1 $WORK_PATH/cluster/$CLUSTER_NAME | wc -l) -eq 1 ]] &&
    [[ $(ls -A -1 $WORK_PATH/cluster/$CLUSTER_NAME | grep "install-config.yaml") ]]; then
    echo "${green}>>>${reset}"
    echo "${green}>>>${reset} Starting Openshift installation..."
    echo "${green}>>>${reset}"

    if $WORK_PATH/install-artifacts/openshift-install create cluster --dir $WORK_PATH/cluster/$CLUSTER_NAME --log-level debug; then
      echo "${green}>>>${reset}"
      echo "${green}>>>${reset} Installation successfull."
      echo "${green}>>>${reset}"
      step_done
    else
      err "installation failed"
      err "investigate the logs in: $WORK_PATH/cluster/$CLUSTER_NAME/.openshift-install.log"
      err "when the issue is resolved retry the installation"
    fi
  else
    err "installation aborted"
    err "cluster directory contains a previous installation or is corrupted"
    err "remove or backup the cluster directory and retry the installation"
  fi
}

function destroy_cluster() {
  step 1

  echo "Destroying cluster..."

  if [[ -z $1 ]]; then
    err "no configuration file provided"
    exit 1
  fi

  if [[ ! -f $1 ]]; then
    err "configuration file $1 not found"
    exit 1
  fi

  source $1

  WORK_PATH=$HOME/$WORK_DIR_NAME

  echo "Checking existance of cluster installation directory..."
  if [[ -d $WORK_PATH/cluster/$CLUSTER_NAME ]]; then
    echo "Cluster directory exist."
  else
    err "no cluster installation directory found"
    err "cluster destruction failed"
    exit 1
  fi

  echo "${green}>>>${reset}"
  echo "${green}>>>${reset} Starting Openshift cluster '$CLUSTER_NAME' destruction..."
  echo "${green}>>>${reset}"

  if $WORK_PATH/install-artifacts/openshift-install destroy cluster --dir $WORK_PATH/cluster/$CLUSTER_NAME --log-level debug; then
    if [[ ! -d $WORK_PATH/archive ]]; then
      echo "Creating archive."
      mkdir $WORK_PATH/archive
    fi

    local archive_name="${CLUSTER_NAME}_$(date +'%d-%m-%y_%H-%M')"
    echo "Archiving cluster data to: $archive_name."
    mv $WORK_PATH/cluster/$CLUSTER_NAME $WORK_PATH/archive/$archive_name

    echo "${green}>>>${reset}"
    echo "${green}>>>${reset} Cluster destruction successfull."
    echo "${green}>>>${reset}"
    step_done
  else
    err "cluster destruction failed"
    err "investigate the logs"
    err "you can uninstall by shutting down and removing the VMs in vSphere"
    exit 1
  fi
}

init

while (("$#")); do
  case "$1" in
  -h | --help)
    show_help=true
    shift
    ;;
  -d | --debug)
    debug=true
    shift
    ;;
  -c | --config)
    if [[ -n "$2" ]]; then
      config_path=$2
      shift 2
    else
      err "argument for $1 is missing" >&2
      exit 1
    fi
    ;;
  -* | --*=)
    err "unsupported flag $1" >&2
    help
    exit 1
    ;;
  *) # preserve positional arguments
    PARAMS="$PARAMS $1"
    shift
    ;;
  esac
done

# set positional arguments in their proper place
eval set -- "$PARAMS"

if [ -z $1 ]; then
  help
  exit 1
fi

if [[ "install" = $1 ]]; then
  if [ "$show_help" = true ]; then
    help $1
    exit 0
  fi

  load_config $config_path
  create_installation_directory_structure
  download_and_decompress_installer
  download_and_decompress_cli
  download_pull_secret
  loading_trust_bundle
  generate_ssh
  generate_install_config
  start_install
fi

if [[ "destroy" = $1 ]]; then
  if [ "$show_help" = true ]; then
    help $1
    exit 0
  fi

  destroy_cluster $config_path
fi
