# script to create bvaeb application namespaces using bvaeb project template
oc process project-request-bvaeb -n openshift-config -p=PROJECT_NAME=bvaeb-telver-dev | oc create -f -
