# script to create svs application namespaces using svs project template
oc process project-request-svs -n openshift-config -p=PROJECT_NAME=svs-polytext-dev | oc create -f -
oc process project-request-svs -n openshift-config -p=PROJECT_NAME=svs-dsl-dev | oc create -f -