# Openshift Day 1 and 2 Automation

## Day 1

### Steps

- Fill configuration file with data for the installation. See [configuration](#configuration-file).
- Make sure the `OFFLINE_ACCESS_TOKEN` environment variable in the `*.env.sh` file is set and valid. See [configuration](#configuration-file).
- Set `VSPHERE_OPENSHIFT_PASSWORD` environment variable.
- Execute installer script providing the path to the configuration file.

### Example Usage

```bash
# installation
VSPHERE_OPENSHIFT_PASSWORD='password'
./installer.sh install -c env/test.env.sh

# show install help
./installer.sh install --help

# destroy existing cluster and archive data
./installer.sh destroy -c env/test.env.sh
```

### During and After Installation

- Once installation starts all data can be found under: `~/$WORK_DIR_NAME`
- Installation directory structure is explained in confluence for each environment e.g. [lab 2 - directories](https://ishare.svdgmbh.at/display/ITPMP/Labor+2+Day+1+Operations#Labor2Day1Operations-Verzeichnisstruktur).
- After installation add following lines to ~/.bashrc replacing `<work-dir-name>` and `<cluster-name>` with the values from the config file.

```bash
# User specific aliases and functions
# Openshift
export KUBECONFIG="$HOME/<work-dir-name>/cluster/<cluster-name>/auth/kubeconfig"
export PATH="$HOME/<work-dir-name>/client:$PATH"
if [[ -x "$(command -v oc)" ]]; then
    source <(oc completion bash)
fi
```

### Files

- Lab environment configuration file: `./day-1/scripts/env/lab.env.sh`
- Lab 2 environment configuration file: `./day-1/scripts/env/lab2.env.sh`
- Test environment configuration file: `./day-1/scripts/env/test.env.sh`
- Installer script: `./day-1/scripts/installer.sh`

### Configuration File

Exmple entries for all environment variables as they were used for lab 1 can be found in the configuration file. Get the detailed explanation for most entries from confluence pages on each environment e.g. [lab 2](https://ishare.svdgmbh.at/display/ITPMP/Labor+2+Day+1+Operations). All entries are mandatory.

Script specific entries:

- `LOCAL_REPO_PATH`: Path to the repository.
- `WORK_DIR_NAME`: Name of the directory where all the installation and configuration files will be put.
- `OFFLINE_ACCESS_TOKEN`: The most recent token is in the `*.env.sh` files.
  - renew token here: [link](https://console.redhat.com/openshift/token)
  - revoke previous tokens here: [link](https://sso.redhat.com/auth/realms/redhat-external/account/#/applications)

Check if the token is still valid using:

```bash
# cd into this repo
cd ~/<path-to-this-repo>

# source the env vars which contain the OFFLINE_ACCESS_TOKEN
source day-1/scripts/env/test.env.sh

# make a http request to Redhat using the correct(!) proxy
curl --silent --proxy http://proxy.svdgmbh.at:8089 --data-urlencode "grant_type=refresh_token" --data-urlencode "client_id=cloud-services" --data-urlencode "refresh_token=${OFFLINE_ACCESS_TOKEN}"  https://sso.redhat.com/auth/realms/redhat-external/protocol/openid-connect/token | jq -r .access_token

# you should get the token as a response if its stil valid OR an error otherwise
eyJhb...
```

## Day 2

### Kustomize

The cluster configuration is organized using Kustomize, so that we can reuse configurations across clusters. It contains cluster resources and namespaced resources. For the configuration deployments to work properly first deploy the namespaces and after that the rest:

```bash
# namespaces first
oc apply -f day-2/base/all-namespaces/all-namespaces.yaml

# all other configurations and resources for e.g. osctest1
oc apply -k day-2/cluster/on-prem/osctest1
```

To check the generated resources for a cluster do:

```bash
mkdir build
oc kustomize day-2/cluster/on-prem/osctest1 -o build
```

No deployment will happen. Only resources will be generated.

#### Structure

- `day-2/base`: contains resources which are shared by *all* clusters, i.e. layer 1
- `day-2/base/all-namespaces/all-namespaces.yaml`: contains all namespace which are needed before any configuration is deployed
- `day-2/overlay/on-prem`: contains pathes and resources which apply to all on-prem clusters, i.e. layer 2
- `day-2/cluster/on-prem/common`: contains resources which are shared between all on-prem clusters, i.e. layer 3
- `day-2/cluster/on-prem/osclab1`: all `osclab1` cluster configuration comes here together, i.e. layer 4
- `day-2/cluster/on-prem/osclab2`: all `osclab2` cluster configuration comes here together, i.e. layer 4
- `day-2/cluster/on-prem/osctest1`: all `osctest1` cluster configuration comes here together, i.e. layer 4
- `day-2/overlay/azure`: contains pathes and resources which apply to all azure/cloud clusters, i.e. layer 2
- `day-2/cluster/azure/arolab0203203`: all `arolab0203203` cluster configuration comes here together, i.e. layer 4

### Users - LDAP

When creating the ldap secret you need to encode the password in base64. When using the `base64` utility use `echo` with the `-n` option to avoid the error described here: [link](https://stackoverflow.com/questions/17484616/base-64-encoding-from-command-line-gives-different-output-than-other-methods).

```bash
echo -n "<password>" | base64
# PHBhc3N3b3JkPg==
```

### Logging

The number of nodes for the Elasticsearch log store should be the same as worker nodes.
